# Standalone pipeline mirrors the notebook: RDKit + GFN1-xTB(tblite) descriptors,
# GPU-aware gradient boosting, split/Mondrian conformal (APS/RAPS). Adapt as needed.
