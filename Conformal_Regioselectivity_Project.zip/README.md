# Physics-Informed Conformal Prediction for Aromatic C–H Site-Selectivity

Guaranteed-coverage prediction sets for electrophilic aromatic substitution (EAS), with a
two-stage descriptor design (RDKit; then GFN1-xTB charge shells). Author: Ali A. Khairbek.

## Dataset
Experimental EAS regioselectivity, 535 compounds / 604
reported reaction centres (Ree, Göller & Jensen; jensengroup/db-regioselectivity, MIT).

## Method
Atom-level descriptors -> gradient-boosted classifier (xgboost, GPU=True) ->
conformal layer (split + Mondrian, APS / RAPS, deterministic). Coverage is multi-label: a set
is covered if it contains at least one reported centre. Target coverage = 0.90.

## Headline numbers (mean over 15 splits)
- Top-1 site accuracy: 0.832
- Coverage (Mondrian, overall): 0.920
- Stage 1 (RDKit):             mean set size 2.80, top-1 0.749
- Stage 2 (RDKit + xTB charge): mean set size 2.74, top-1 0.818
- Stage 3 (+ Fukui f-):         mean set size 2.62, top-1 0.862
- Ablation: the most informative electronic descriptor is fukui_f
- Efficiency curve: set size 4.53 -> 2.60 across the descriptor budget
  (coverage held at target); the GFN1-xTB block tests whether electronic structure breaks the
  RDKit plateau.

## Contents
- figures/ : fig1_validity, fig2_conditional_coverage, fig3_setsize, fig4_efficiency_curve,
             fig4b_stage_comparison, fig5_credibility_ood, fig6_ablation,
             fig7_fukui_validation, fig8_reagent_robustness (300 dpi)
- metrics_coverage.csv, metrics_efficiency_curve.csv, metrics_stage_comparison.csv,
  metrics_ablation.csv, metrics_fukui_validation.csv, metrics_reagent_robustness.csv, summary.json
- pipeline.py